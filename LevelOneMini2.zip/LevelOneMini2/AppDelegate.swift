//
//  AppDelegate.swift
//  LevelOneMini2
//
//  Created by tandyys on 18/06/24.
//


import Cocoa

@main
class AppDelegate: NSObject, NSApplicationDelegate {
    
    func applicationDidFinishLaunching(_ aNotification: Notification) {
        // Insert code here to initialize your application
//        guard let window = NSApplication.shared.windows.first else {
//            return
//        }
//        
//        window.toggleFullScreen(nil)
    }
    
    func applicationWillTerminate(_ aNotification: Notification) {
        // Insert code here to tear down your application
    }
    
    
}
